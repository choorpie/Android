package com.example.roomexample.Adapter

//interface that should be implemented in the recyclerview's adapter
interface SwipeHandlerInterface {
    fun onItemDelete(position: Int)
}