package com.example.viewpagerexamplefragment

//scene data structure
data class Scenes(val id: Int, val city: String, val name: String, val photoId: Int, val description: String)
