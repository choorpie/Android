package com.example.recycleviewballlist

data class Balls(val name: String, val imageId: Int)