package com.example.viewpagerexample

data class Photos(val location: String, val photoId: Int)
